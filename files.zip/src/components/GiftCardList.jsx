import React, { useState, useEffect } from 'react';
import axios from 'axios';

function GiftCardList() {
    const [giftCards, setGiftCards] = useState(() => {
        const savedCards = localStorage.getItem('giftCards');
        return savedCards ? JSON.parse(savedCards) : [];
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchGiftCards = async () => {
            try {
                const { data } = await axios.get('http://localhost:8000/giftcards');
                setGiftCards(data);
                localStorage.setItem('giftCards', JSON.stringify(data));  // Cache data in local storage
                setLoading(false);
            } catch (error) {
                console.error('Error fetching gift cards:', error);
                setLoading(false);
            }
        };

        if (giftCards.length === 0) {
            fetchGiftCards();  // Only fetch data if not already cached
        } else {
            setLoading(false);  // No need to load again if data is in local storage
        }
    }, [giftCards]);

    if (loading) {
        return <p>Loading gift cards...</p>;
    }

    return (
        <div>
            <h2>Gift Card List</h2>
            <div>
                {giftCards.length > 0 ? (
                    giftCards.map((card, index) => (
                        <li key={index}>
                            <p><strong>Type:</strong> {card.giftCardType}</p>
                            <p><strong>Amount:</strong> ${card.amount}</p>
                            <p><strong>Email:</strong> {card.email}</p>
                            <div>
                                <p>Front Image:</p>
                                {card.frontImage && (
                                    <img
                                        src={card.frontImage}  // Base64 image
                                        alt="Front of gift card"
                                        width={200}
                                    />
                                )}
                            </div>
                            <div>
                                <p>Back Image:</p>
                                {card.backImage && (
                                    <img
                                        src={card.backImage}  // Base64 image
                                        alt="Back of gift card"
                                        width={200}
                                    />
                                )}
                            </div>
                        </li>
                    ))
                ) : (
                    <p>No gift cards found</p>
                )}
            </div>
        </div>
    );
}

export default GiftCardList;
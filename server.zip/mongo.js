import mongoose from 'mongoose';

// Corrected connection string with the specified database
mongoose.connect("mongodb+srv://teefeh26:passworddd@cluster0.tkzze.mongodb.net/Database", {
  serverSelectionTimeoutMS: 30000 
}).then(() => {
    console.log("connected to MongoDB");
  })
  .catch((err) => {
    console.error("Failed to connect to MongoDB", err);
  });

// Updated Schema to include base64 images
const newSchema = new mongoose.Schema({
  giftCardType: {
    type: String,
    required: true
  },
  amount: {
    type: Number,  // Use Number instead of String for amount
    required: true
  },
  email: {
    type: String,
    required: true
  },
  frontImage: {
    type: String,  // Store base64 image as a String
    required: true
  },
  backImage: {
    type: String,  // Store base64 image as a String
    required: true
  }
});

// Explicitly specify collection name if necessary (e.g., "giftcards")
const collection = mongoose.model("GiftCard", newSchema, 'giftcards');

export default collection;

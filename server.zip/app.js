import express from 'express';
import collection from './mongo.js';
import mongoose from 'mongoose';
import cors from 'cors';

const app = express();
app.use(cors());

// Increase the limit for JSON and URL-encoded requests
app.use(express.json({ limit: '50mb' }));  // Increase the size limit for JSON payloads
app.use(express.urlencoded({ limit: '50mb', extended: true }));  // Increase the size limit for form submissions

// Test route
app.get('/', (req, res) => {
  res.send('Server is up and running');
});

// GET route to fetch all gift cards from MongoDB
app.get('/giftcards', async (req, res) => {
  try {
    const giftcards = await collection.find({});  // Fetch all gift cards from MongoDB
    res.json(giftcards);  // Send gift cards as JSON response
  } catch (err) {
    console.error("Error fetching gift cards:", err);
    res.status(500).send("Error fetching gift cards");
  }
});

// POST route to handle form submission and image upload
app.post('/', async (req, res) => {
  try {
    // Log the request body to ensure you receive the data correctly
    console.log(req.body);

    // Destructure the data from the request body
    const { giftCardType, amount, email, frontImage, backImage } = req.body;

    // Prepare the data object to insert into MongoDB
    const data = {
      giftCardType,
      amount,
      email,
      frontImage,  // Store the base64-encoded front image
      backImage    // Store the base64-encoded back image
    };

    // Insert the data into the MongoDB collection
    await collection.insertMany([data]);

    // Send a success response back to the client
    res.status(200).send("Data and images inserted successfully");
  } catch (err) {
    console.error("Error inserting data:", err);
    res.status(500).send("Error inserting data");
  }
});

// Start the server on port 8000
app.listen(8000, () => {
  console.log("Server is running on port 8000");
});
